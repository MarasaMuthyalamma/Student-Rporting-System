package com.student.Student.Reporting.System.StudentController;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.student.Student.Reporting.System.domain.Student;

@Controller
public class StudentController 
{
    @RequestMapping(value="/StudentReport")
    public String StudentDetails(@RequestParam String english,@RequestParam  String maths,
    		@RequestParam String science,@RequestParam String java,@RequestParam  String python,
    		@RequestParam String php,Model model)
    {
    	model.addAttribute("English", english);
    	model.addAttribute("Maths", maths);
    	model.addAttribute("Science", science);
    	model.addAttribute("Java", java);
    	model.addAttribute("Python", python);
    	model.addAttribute("Php", php);
    	{
        return "result";
    	}
    }
}
    

