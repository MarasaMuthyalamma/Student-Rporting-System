package com.student.Student.Reporting.System.domain;

public class Student {
	private int English;
	private int Maths;
	private int Science;
	private  int Java;
	private int Python;
	private int Php;
	private int Semister1;
	private int Semister2;
	public int getEnglish() {
		return English;
	}
	public void setEnglish(int english) {
		English = english;
	}
	public int getMaths() {
		return Maths;
	}
	public void setMaths(int maths) {
		Maths = maths;
	}
	public int getScience() {
		return Science;
	}
	public void setScience(int science) {
		Science = science;
	}
	public int getJava() {
		return Java;
	}
	public void setJava(int java) {
		Java = java;
	}
	public int getPython() {
		return Python;
	}
	public void setPython(int python) {
		Python = python;
	}
	public int getPhp() {
		return Php;
	}
	public void setPhp(int php) {
		Php = php;
	}
	public int getSemister1() {
		Semister1=English+Maths+Science;
		return Semister1;
	}
	public void setSemister1(int semister1) {
		Semister1 = semister1;
	}
	public int getSemister2() {
		Semister2=Java+Python+Php;
		return  Semister2;
	}
	public void setSemister2(int semister2) {
		Semister2 = semister2;
	}
	public double getAvarageOfRecentSemister()
	{
		double AvgOfRecentSem=Semister2/3;
		return  AvgOfRecentSem;
	}
	public double getTotalAvg()
	{
		double TotalAvg=Semister1+Semister2;
		return TotalAvg/2;
	}
	

}
