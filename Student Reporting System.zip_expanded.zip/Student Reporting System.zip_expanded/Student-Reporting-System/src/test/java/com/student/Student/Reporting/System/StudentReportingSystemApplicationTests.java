package com.student.Student.Reporting.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentReportingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
